<?php 
$koneksi=mysqli_connect("localhost","root","","db_apotik");
?>